for x in range(0, 11):
    print(x)
