name : str = "John"

print("Hello " + name + ".")

age : int = 40

print(name + " is " + str(age) + " years old.")