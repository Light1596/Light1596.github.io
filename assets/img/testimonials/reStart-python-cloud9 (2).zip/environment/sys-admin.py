'''

Python has several modules to allow you to run Bash commands from Python. 
In this exercise, you will use os.system() to run the Bash command ls, 
which shows the directory contents.

'''

import os

os.system('ls')

'''
The output should show the contents of your current directory. 
Verify that your output is similar to the following example. 
Note that the contents of your directory might be different.

'''