"""
LISTS
"""
# myFruitList = ["apple" , "banana" , "cherry"]
# myFruitList.append("Orange")
# print(myFruitList)
# print(type(myFruitList))
# print(myFruitList[0])#Accesses apple
# print(myFruitList[1])#Accesses banana
# print(myFruitList[2])#Accesses cherry
# del myFruitList[3]
# print(myFruitList)

'''
TUPLE
'''
# myFinalAnswerTuple = "apple", "banana", "pineapple"
# print(myFinalAnswerTuple)
# print(type(myFinalAnswerTuple))
# print(myFinalAnswerTuple[0])  #Access apple
# print(myFinalAnswerTuple[1])  #Access banana
# print(myFinalAnswerTuple[2])  #Access pineapple

'''
DICTIONARY
'''
myFavoriteFruitDictionary = {
    "Akua" : "Apple",
    "Saanvi" : "banana",
    "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary.items(), myFavoriteFruitDictionary.keys(), myFavoriteFruitDictionary.values())
