# # print("Python has three numeric types: int, float and complex")
# myValue=1
# print(f"{myValue}, {type(myValue)}")
# print("It is a value ", myValue)
# print("It is a value " + str(myValue) + str(type(myValue)))

'''
FLOAT DATA TYPE
'''

# myValue=3.14
# print(myValue,type(myValue))

'''
COMPLEX NUMBERS
'''

# myValue=5j
# print(myValue,type(myValue))
# print(str(myValue) + "is a complex number")

'''
Boolean
'''

myValue=True
print(myValue, type(myValue))