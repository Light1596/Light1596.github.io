"""
Your module description
"""
# myString = "This is a string."
# print(myString)

# firstString = "Water"
# secondString = "fall"
# thirdString = firstString + secondString
# print(thirdString)

name = input("What is your name?")
# print(name)


color = input("What is your favorite color?")
animal = input("what is your favorite animal?")
print("{}, you like a {} {}!".format(name,color,animal))