# Creating functions

def getDoubleAlphabet(alphabet : str) -> str:
    
    doubleAlphabet : str = alphabet + alphabet
    
    return doubleAlphabet
    
# print(getDoubleAlphabet("ABC"))

#Ex 2

def getMessage() -> str :
    
    stringToEncrypt : str = input("Please enter a message to encrypt: ")
    
    return stringToEncrypt
    
    
#Ex 3
# Gettin a cipher key
def getCipherKey() -> str :
    
    '''
    The cipher key is how far you will shift the letters. By using two alphabets,
    you can have a cipher key that is any integer from 1 to 25. 
    Don’t count the key at index 26 because that key would shift 
    you back to the original message.
    
    '''
    
    shiftAmount : str = input("Please enter a key (whole number from 1-25): ")
    
    return shiftAmount
    
    
#Ex 4

def encryptMessage(message : str, cipherKey : int , alphabet : str) -> str:
    
    '''
    Take three arguments: the message, the cipherKey, and the alphabet.

    Initialize variables.
    
    Use a for loop to traverse each letter in the message.
    
    For a specific letter, find the position.
    
    For a specific letter, determine the new position given the cipher key.
    
    If current letter is in the alphabet, append the new letter to the encrypted message.
    
    If current letter is not in the alphabet, append the current letter.
    
    Return the encrypted message after exhausting all the letters in the message.
        
    
    '''
    encryptedMessage : str = ""
    
    uppercaseMessage : str = ""
    
    uppercaseMessage : str = message.upper()
    
    for currentCharacter in uppercaseMessage:
        
        position : int = alphabet.find(currentCharacter)
        
        newPosition : int =  position + int(cipherKey)
        
        if currentCharacter in alphabet:
            
            encryptedMessage = encryptedMessage + alphabet[newPosition]
            
        else:
            
            encryptedMessage = encryptedMessage + currentCharacter
            
    return encryptedMessage
    
    
#Ex 5

def decryptMessage(message : str , cipherKey : str ,alphabet : str) -> str:
    
    '''
    Functions are useful because you can reuse them. You will write a decryptMessage() 
    function by reusing the encryptMessage() function. For this simple encryption, you can 
    undo the encryption by shifting each letter back. Thus, instead of adding the cipher key, 
    you will subtract the cipher key. To avoid rewriting most of the logic, 
    you will pass in a negative cipher key.
    
    '''
    
    decryptKey : int = -1 * int(cipherKey)
    
    return encryptMessage(message, decryptKey, alphabet)
    
#Ex 6

def runCaesarCipherProgram() -> str:
    '''
    Here is the logic
    Define a string variable to contain the English alphabet.

    To be able to shift letters, double your alphabet string.

    Get a message to encrypt from the user.

    Get a cipher key from the user.

    Encrypt the message.

    Decrypt the message.
    
    '''
    
    myAlphabet : str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    
    print(f'Alphabet :{myAlphabet}')
    
    myAlphabet2 : str = getDoubleAlphabet(myAlphabet)
    
    print(f"Alphabet2: {myAlphabet2}")
    
    myMessage : str = getMessage()
    
    print(myMessage)
    
    myCipherkey : str = getCipherKey()
    
    print(myCipherkey)
    
    myEncryptedMessage = encryptMessage(myMessage , myCipherkey, myAlphabet2)
    
    print(f'Encrypted Message : {myEncryptedMessage}')
    
    myDecryptedMessage : str = decryptMessage(myEncryptedMessage, myCipherkey, myAlphabet2)
    
    print(f'Decrypted Message : {myDecryptedMessage}')
    
runCaesarCipherProgram()