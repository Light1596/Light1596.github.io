import re

# Read the file
with open('preproinsulin-seq.txt', 'r') as file:
    content = file.read()

# Clean the content
cleaned_content = re.sub(r'ORIGIN|\d+|\/\/|\s+', '', content)

# Count characters
#char_count = len(cleaned_content)

# Output cleaned content
#print(cleaned_content)

# Confirm character count
# if char_count == 110:
#     print("Character count is correct.")
# else:
#     print("Character count is not correct.")
# with open('preproinsulin-seq-clean2.txt','w') as cleaned_file:
#     cleaned_file.write(cleaned_content)
    
with open('preproinsulin-seq-clean2.txt','r') as amino1:
    content2 = amino1.read()
    
    
    IsInsulin : str = content2[0:24]

    print(len(IsInsulin))

    with open('Insulin-seq-clean.txt','w') as cleaned3:
        cleaned3.write(IsInsulin)

    biinsu : str = content2[24:54]
    print(len(biinsu))


    with open('binsulin-seq-clean.txt','w') as cleaned4:
        cleaned4.write(biinsu)
    
    cinsu : str = content2[54:89]
    
    with open("cinsulin-seq-clean.txt",'w') as cleaned5:
        cleaned5.write(cinsu)
    
    ainsu : str = content2[89:110]
    
    with open("ainsulin-seq-clean.txt",'w') as cleaned6:
        cleaned6.write(ainsu)