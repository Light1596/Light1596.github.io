'''
Though os.system() is simple to use because it takes a string argument,
it is recommended that you use the more powerful subprocess.run() function.
You can use the subprocess module to spawn new processes, connect to input/output/error pipes,
and obtain error codes. The subprocess.run() function can take many new arguments,
but those additional arguments are optional.

The syntax looks like:
|
|
subprocess.run(args, *, stdin=None, input=None, stdout=None, stderr=None, capture_output=False, 
shell=False, cwd=None, timeout=None, check=False, encoding=None, errors=None, text=None, env=None,
universal_newlines=None)

'''

import subprocess

subprocess.run(["ls"])

'''
 The output lists the file in the directory

'''

print("-------------------------------------")
print("|     EXERCISE                      |")
print("|        TWO                        |")
print("-------------------------------------")

#EXERCISE 3
'''
In Python, the square brackets are list data types, which means that run() can take
a list of arguments. 

'''

subprocess.run(['ls','-l','-a','README.md'])

print("-------------------------------------")
print("|     EXERCISE                      |")
print("|        FIVE                       |")
print("-------------------------------------")

command : str = "uname"

commandArgument = "-a"

print(f'Gathering system information with command: {command} {commandArgument}')

subprocess.run([command,commandArgument])


print("-------------------------------------")
print("|     EXERCISE                      |")
print("|        SIX                        |")
print("-------------------------------------")

'''
The error in the code lies in the way you're attempting to use pipes (|) between commands. 
You're trying to use pipes as if you're using them directly in the shell, 
but subprocess.run() doesn't interpret shell syntax by default.

To fix this, you can set shell=True in the subprocess.run() call to enable shell mode, 
allowing the use of shell-specific syntax like pipes. Here's the corrected code:



'''

command = "ps"
commandArgument = "-x"
command3 = "|"
command4 = " pwd"
command6 = "wget 'https://tukenya.ac.ke/'"

# Use shell mode with shell=True to allow pipe usage
print(f'Gathering active process information with command: {command} {commandArgument}')
subprocess.run(f"{command} {commandArgument} {command3} {command4} {command6}", shell=True)
